import 'package:flutter/material.dart';

import 'package:nordic_nrf_mesh_example/src/app.dart';

void main() => runApp(const NordicNrfMeshExampleApp());
