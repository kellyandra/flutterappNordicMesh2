// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'config_default_ttl_status.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ConfigDefaultTtlStatus _$_$_ConfigDefaultTtlStatusFromJson(Map<String, dynamic> json) {
  return _$_ConfigDefaultTtlStatus(
    json['source'] as int,
    json['destination'] as int,
    json['ttl'] as int,
  );
}

Map<String, dynamic> _$_$_ConfigDefaultTtlStatusToJson(_$_ConfigDefaultTtlStatus instance) => <String, dynamic>{
      'source': instance.source,
      'destination': instance.destination,
      'ttl': instance.ttl,
    };
