// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'config_model_app_status.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ConfigModelAppStatusData _$_$_ConfigModelAppStatusDataFromJson(Map<String, dynamic> json) {
  return _$_ConfigModelAppStatusData(
    json['elementAddress'] as int,
    json['modelId'] as int,
    json['appKeyIndex'] as int,
  );
}

Map<String, dynamic> _$_$_ConfigModelAppStatusDataToJson(_$_ConfigModelAppStatusData instance) => <String, dynamic>{
      'elementAddress': instance.elementAddress,
      'modelId': instance.modelId,
      'appKeyIndex': instance.appKeyIndex,
    };
