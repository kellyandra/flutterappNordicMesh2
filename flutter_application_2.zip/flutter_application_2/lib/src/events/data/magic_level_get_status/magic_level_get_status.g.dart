// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'magic_level_get_status.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MagicLevelGetStatusData _$_$_MagicLevelGetStatusDataFromJson(Map<String, dynamic> json) {
  return _$_MagicLevelGetStatusData(
    json['io'] as int,
    json['index'] as int,
    json['value'] as int,
    json['correlation'] as int,
    json['source'] as int,
    json['destination'] as int,
  );
}

Map<String, dynamic> _$_$_MagicLevelGetStatusDataToJson(_$_MagicLevelGetStatusData instance) => <String, dynamic>{
      'io': instance.io,
      'index': instance.index,
      'value': instance.value,
      'correlation': instance.correlation,
      'source': instance.source,
      'destination': instance.destination,
    };
