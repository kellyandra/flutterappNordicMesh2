// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'magic_level_set_status.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MagicLevelSetStatusData _$_$_MagicLevelSetStatusDataFromJson(Map<String, dynamic> json) {
  return _$_MagicLevelSetStatusData(
    json['io'] as int,
    json['index'] as int,
    json['value'] as int,
    json['correlation'] as int,
    json['source'] as int,
    json['destination'] as int,
  );
}

Map<String, dynamic> _$_$_MagicLevelSetStatusDataToJson(_$_MagicLevelSetStatusData instance) => <String, dynamic>{
      'io': instance.io,
      'index': instance.index,
      'value': instance.value,
      'correlation': instance.correlation,
      'source': instance.source,
      'destination': instance.destination,
    };
