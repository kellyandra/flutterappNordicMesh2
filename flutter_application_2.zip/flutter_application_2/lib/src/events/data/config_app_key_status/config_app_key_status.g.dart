// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'config_app_key_status.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ConfigAppKeyStatusData _$_$_ConfigAppKeyStatusDataFromJson(Map<String, dynamic> json) {
  return _$_ConfigAppKeyStatusData(
    json['source'] as int,
  );
}

Map<String, dynamic> _$_$_ConfigAppKeyStatusDataToJson(_$_ConfigAppKeyStatusData instance) => <String, dynamic>{
      'source': instance.source,
    };

_$_ConfigAppKeyStatusMeshMessage _$_$_ConfigAppKeyStatusMeshMessageFromJson(Map<String, dynamic> json) {
  return _$_ConfigAppKeyStatusMeshMessage(
    json['source'] as int,
    json['destination'] as int,
  );
}

Map<String, dynamic> _$_$_ConfigAppKeyStatusMeshMessageToJson(_$_ConfigAppKeyStatusMeshMessage instance) =>
    <String, dynamic>{
      'source': instance.source,
      'destination': instance.destination,
    };
