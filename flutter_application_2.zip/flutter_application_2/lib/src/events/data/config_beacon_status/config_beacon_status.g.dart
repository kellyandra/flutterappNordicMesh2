// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'config_beacon_status.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ConfigBeaconStatus _$_$_ConfigBeaconStatusFromJson(Map<String, dynamic> json) {
  return _$_ConfigBeaconStatus(
    json['source'] as int,
    json['destination'] as int,
    json['enable'] as bool,
  );
}

Map<String, dynamic> _$_$_ConfigBeaconStatusToJson(_$_ConfigBeaconStatus instance) => <String, dynamic>{
      'source': instance.source,
      'destination': instance.destination,
      'enable': instance.enable,
    };
