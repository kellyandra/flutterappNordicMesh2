// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mesh_network_event.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_MeshNetworkEventData _$_$_MeshNetworkEventDataFromJson(Map<String, dynamic> json) {
  return _$_MeshNetworkEventData(
    json['id'] as String,
  );
}

Map<String, dynamic> _$_$_MeshNetworkEventDataToJson(_$_MeshNetworkEventData instance) => <String, dynamic>{
      'id': instance.id,
    };

_$_MeshNetworkEventError _$_$_MeshNetworkEventErrorFromJson(Map<String, dynamic> json) {
  return _$_MeshNetworkEventError(
    json['error'] as String,
  );
}

Map<String, dynamic> _$_$_MeshNetworkEventErrorToJson(_$_MeshNetworkEventError instance) => <String, dynamic>{
      'error': instance.error,
    };
