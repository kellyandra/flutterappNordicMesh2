// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'allocated_scene_range.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AllocatedSceneRange _$_$_AllocatedSceneRangeFromJson(Map<String, dynamic> json) {
  return _$_AllocatedSceneRange(
    json['firstScene'] as int,
    json['lastScene'] as int,
  );
}

Map<String, dynamic> _$_$_AllocatedSceneRangeToJson(_$_AllocatedSceneRange instance) => <String, dynamic>{
      'firstScene': instance.firstScene,
      'lastScene': instance.lastScene,
    };
