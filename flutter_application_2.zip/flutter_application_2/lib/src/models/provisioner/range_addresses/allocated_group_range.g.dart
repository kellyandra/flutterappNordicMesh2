// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'allocated_group_range.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AllocatedGroupRange _$_$_AllocatedGroupRangeFromJson(Map<String, dynamic> json) {
  return _$_AllocatedGroupRange(
    json['lowAddress'] as int,
    json['highAddress'] as int,
  );
}

Map<String, dynamic> _$_$_AllocatedGroupRangeToJson(_$_AllocatedGroupRange instance) => <String, dynamic>{
      'lowAddress': instance.lowAddress,
      'highAddress': instance.highAddress,
    };
