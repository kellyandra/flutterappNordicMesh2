// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'allocated_unicast_range.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_AllocatedUnicastRange _$_$_AllocatedUnicastRangeFromJson(Map<String, dynamic> json) {
  return _$_AllocatedUnicastRange(
    json['lowAddress'] as int,
    json['highAddress'] as int,
  );
}

Map<String, dynamic> _$_$_AllocatedUnicastRangeToJson(_$_AllocatedUnicastRange instance) => <String, dynamic>{
      'lowAddress': instance.lowAddress,
      'highAddress': instance.highAddress,
    };
